#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG_FILE="${SCRIPT_DIR}/infra.conf"
HOSTS_FILE="${SCRIPT_DIR}/hosts.csv"
ENGINE_FILE="${SCRIPT_DIR}/linuxinfra_engine.sh"

if [[ -t 1 ]]; then
  C_RESET=$'\033[0m'
  C_BOLD=$'\033[1m'
  C_BLUE=$'\033[1;34m'
  C_CYAN=$'\033[1;36m'
  C_GREEN=$'\033[1;32m'
  C_YELLOW=$'\033[1;33m'
  C_MAGENTA=$'\033[1;35m'
  C_RED=$'\033[1;31m'
else
  C_RESET=""
  C_BOLD=""
  C_BLUE=""
  C_CYAN=""
  C_GREEN=""
  C_YELLOW=""
  C_MAGENTA=""
  C_RED=""
fi

normalize_text_file() {
  local file="$1"
  local label="$2"
  if [[ -f "$file" ]] && grep -q $'\r' "$file" 2>/dev/null; then
    printf '%sNormalizing Windows line endings in %s%s\n' "$C_YELLOW" "$label" "$C_RESET"
    if command -v dos2unix >/dev/null 2>&1; then
      dos2unix -q "$file"
    else
      sed -i 's/\r$//' "$file"
    fi
  fi
}

load_host_preview() {
  local role="$1"
  awk -F'|' -v role="$role" '
    $0 !~ /^#/ && NF >= 8 && $1 == role {
      gsub(/^[[:space:]]+|[[:space:]]+$/, "", $2)
      gsub(/^[[:space:]]+|[[:space:]]+$/, "", $3)
      gsub(/^[[:space:]]+|[[:space:]]+$/, "", $4)
      gsub(/^[[:space:]]+|[[:space:]]+$/, "", $5)
      gsub(/^[[:space:]]+|[[:space:]]+$/, "", $7)
      printf "%s|%s|%s|%s|%s\n", $2, $3, $4, $5, $7
      exit
    }
  ' "$HOSTS_FILE"
}

show_banner() {
  printf '\n%s%s========================================================%s\n' "$C_BLUE" "$C_BOLD" "$C_RESET"
  printf '%s%s' "$C_CYAN" "$C_BOLD"
  cat <<'EOF'
 _      _                 _____        __
| |    (_)               |_   _|      / _|
| |     _ _ __  _   ___  ___| |  _ __| |_ _ __ __ _
| |    | | '_ \| | | \ \/ / | | | '__|  _| '__/ _` |
| |____| | | | | |_| |>  < _| |_| |  | | | | | (_| |
|______|_|_| |_|\__,_/_/\_\_____|_|  |_| |_|  \__,_|
EOF
  printf '%s\n' "$C_RESET"
  printf '%s%s           LinuxInfra Deployment Framework%s\n' "$C_MAGENTA" "$C_BOLD" "$C_RESET"
  printf '%s%s                     Version %s%s%s\n' "$C_GREEN" "$C_BOLD" "${PROJECT_VERSION:-0.7.3}" "$C_RESET" ""
  printf '%s%s========================================================%s\n\n' "$C_BLUE" "$C_BOLD" "$C_RESET"
}

show_role_preview() {
  local role="$1"
  local preview
  preview="$(load_host_preview "$role" || true)"
  if [[ -z "$preview" ]]; then
    echo "No host preview found for role: $role"
    return 1
  fi
  IFS='|' read -r hostname ip gateway iface label <<< "$preview"
  printf '%sRole%s           : %s%s%s\n' "$C_CYAN" "$C_RESET" "$C_BOLD" "$role" "$C_RESET"
  printf '%sHostname%s       : %s%s%s\n' "$C_CYAN" "$C_RESET" "$C_BOLD" "$hostname" "$C_RESET"
  printf '%sIP/CIDR%s        : %s%s%s\n' "$C_CYAN" "$C_RESET" "$C_BOLD" "$ip" "$C_RESET"
  printf '%sGateway%s        : %s%s%s\n' "$C_CYAN" "$C_RESET" "$C_BOLD" "$gateway" "$C_RESET"
  printf '%sInterface%s      : %s%s%s\n' "$C_CYAN" "$C_RESET" "$C_BOLD" "$iface" "$C_RESET"
  printf '%sHost label%s     : %s%s%s\n' "$C_CYAN" "$C_RESET" "$C_BOLD" "$label" "$C_RESET"
  case "$role" in
    siem)
      printf '%sFirewall%s       : SIEM + DNS policy%s\n' "$C_YELLOW" "$C_RESET" "$C_RESET"
      printf '%sDNS assets%s     : will be prepared%s\n' "$C_YELLOW" "$C_RESET" "$C_RESET"
      ;;
    internal)
      printf '%sFirewall%s       : mail policy%s\n' "$C_YELLOW" "$C_RESET" "$C_RESET"
      printf '%sMail role%s      : internal server%s\n' "$C_YELLOW" "$C_RESET" "$C_RESET"
      ;;
    external)
      printf '%sFirewall%s       : mail policy%s\n' "$C_YELLOW" "$C_RESET" "$C_RESET"
      printf '%sMail role%s      : external server%s\n' "$C_YELLOW" "$C_RESET" "$C_RESET"
      ;;
    repo)
      printf '%sFirewall%s       : repo + registry policy%s\n' "$C_YELLOW" "$C_RESET" "$C_RESET"
      printf '%sLab role%s       : repository server%s\n' "$C_YELLOW" "$C_RESET" "$C_RESET"
      ;;
    proxy)
      printf '%sFirewall%s       : proxy policy%s\n' "$C_YELLOW" "$C_RESET" "$C_RESET"
      printf '%sLab role%s       : squid / traffic proxy%s\n' "$C_YELLOW" "$C_RESET" "$C_RESET"
      ;;
    cloud)
      printf '%sFirewall%s       : cloud connector policy%s\n' "$C_YELLOW" "$C_RESET" "$C_RESET"
      printf '%sLab role%s       : cloud integration node%s\n' "$C_YELLOW" "$C_RESET" "$C_RESET"
      ;;
  esac
  printf '%sTimezone%s       : %s%s%s\n' "$C_CYAN" "$C_RESET" "$C_BOLD" "${TIMEZONE:-Asia/Kolkata}" "$C_RESET"
  printf '%sNTP%s            : %s%s%s\n' "$C_CYAN" "$C_RESET" "$C_BOLD" "${NTP_SERVER:-time.google.com}" "$C_RESET"
}

prompt_role() {
  local choice
  while true; do
    show_banner
    printf '%sSelect Server Role%s\n\n' "$C_BOLD" "$C_RESET"
    printf '1) SIEM + DNS\n'
    printf '2) Internal Mail Server\n'
    printf '3) External Mail Server\n'
    printf '4) Repo Server\n'
    printf '5) Proxy Server\n'
    printf '6) Cloud Connector\n'
    printf '7) Dry Run / Validate Only\n'
    printf '8) Exit\n\n'
    read -r -p 'Enter choice [1-8]: ' choice
    case "$choice" in
      1) ROLE="siem"; MODE="build"; break ;;
      2) ROLE="internal"; MODE="build"; break ;;
      3) ROLE="external"; MODE="build"; break ;;
      4) ROLE="repo"; MODE="build"; break ;;
      5) ROLE="proxy"; MODE="build"; break ;;
      6) ROLE="cloud"; MODE="build"; break ;;
      7)
        show_banner
        printf '%sDry Run Role Selection%s\n\n' "$C_BOLD" "$C_RESET"
        printf '1) SIEM + DNS\n'
        printf '2) Internal Mail Server\n'
        printf '3) External Mail Server\n'
        printf '4) Repo Server\n'
        printf '5) Proxy Server\n'
        printf '6) Cloud Connector\n\n'
        read -r -p 'Enter dry-run role [1-6]: ' choice
        case "$choice" in
          1) ROLE="siem" ;;
          2) ROLE="internal" ;;
          3) ROLE="external" ;;
          4) ROLE="repo" ;;
          5) ROLE="proxy" ;;
          6) ROLE="cloud" ;;
          *) echo 'Invalid dry-run role'; continue ;;
        esac
        MODE="dry-run"
        break
        ;;
      8) exit 0 ;;
      *) echo 'Invalid choice. Try again.' ; sleep 1 ;;
    esac
  done
}

main() {
  if [[ ${EUID} -ne 0 ]]; then
    echo "ERROR: Run this script as root: sudo ./LinuxInfra.sh" >&2
    exit 2
  fi

  if [[ ! -r "$CONFIG_FILE" || ! -r "$HOSTS_FILE" || ! -x "$ENGINE_FILE" ]]; then
    echo "ERROR: infra.conf, hosts.csv, and linuxinfra_engine.sh must exist beside this script." >&2
    exit 2
  fi

  normalize_text_file "$CONFIG_FILE" "infra.conf"
  normalize_text_file "$HOSTS_FILE" "hosts.csv"

  # shellcheck source=/dev/null
  source "$CONFIG_FILE"

  prompt_role

  show_banner
  echo "Selected Role Summary"
  echo
  show_role_preview "$ROLE"
  echo
  if [[ "$MODE" == "dry-run" ]]; then
    printf '%sMode%s           : DRY RUN / VALIDATE ONLY\n' "$C_MAGENTA" "$C_RESET"
  else
    printf '%sMode%s           : BUILD\n' "$C_GREEN" "$C_RESET"
  fi
  echo
  read -r -p 'Proceed with this server build? [y/N]: ' answer
  case "${answer,,}" in
    y|yes) ;;
    *) echo 'Cancelled.'; exit 0 ;;
  esac

  exec "$ENGINE_FILE" "$ROLE" "$MODE"
}

main "$@"
