#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG_FILE="${SCRIPT_DIR}/mailcowconfig.conf"
MAILCOW_DIR="/opt/mailcow-dockerized"
LOG_DIR="${SCRIPT_DIR}/logs"
mkdir -p "${LOG_DIR}"
RUN_ID="$(date +%Y%m%d-%H%M%S)"
LOG_FILE="${LOG_DIR}/mailcowconfig-${RUN_ID}.log"
SUMMARY_FILE="${LOG_DIR}/status_summary.txt"
DETAIL_FILE="${LOG_DIR}/detailed_debug.log"
LATEST_DIR="${LOG_DIR}/latest"
mkdir -p "${LATEST_DIR}"

exec > >(tee -a "${LOG_FILE}" "${DETAIL_FILE}") 2>&1

info() { printf '[%s] [INFO] %s\n' "$(date '+%F %T')" "$*"; }
warn() { printf '[%s] [WARN] %s\n' "$(date '+%F %T')" "$*"; }
err()  { printf '[%s] [ERR ] %s\n' "$(date '+%F %T')" "$*"; }

banner() {
  cat <<'BANNER'
============================================================
                 MailcowConfig v1.0.0
============================================================
BANNER
}

load_config() {
  if [[ -f "${CONFIG_FILE}" ]]; then
    # shellcheck disable=SC1090
    source "${CONFIG_FILE}"
  else
    warn "Config file not found: ${CONFIG_FILE}. Using built-in defaults."
    ROLE="${ROLE:-internal}"
  fi

  ROLE="${ROLE:-internal}"
  case "${ROLE}" in
    internal)
      HOSTNAME="${HOSTNAME:-mail.internal.local}"
      MAIL_DOMAIN="${MAIL_DOMAIN:-internal.local}"
      TARGET_IP="${TARGET_IP:-192.168.10.11}"
      ;;
    external)
      HOSTNAME="${HOSTNAME:-mail.external.local}"
      MAIL_DOMAIN="${MAIL_DOMAIN:-external.local}"
      TARGET_IP="${TARGET_IP:-192.168.10.12}"
      ;;
    *)
      err "Unknown ROLE=${ROLE}. Use internal or external."
      exit 1
      ;;
  esac

  MAILCOW_HOSTNAME="${MAILCOW_HOSTNAME:-${HOSTNAME}}"
  TRUSTED_NETWORKS="${TRUSTED_NETWORKS:-127.0.0.1 172.22.1.0/24 192.168.10.0/24}"
}

check_prereqs() {
  local miss=0

  # MailcowConfig assumes LinuxInfra + MailcowBootstrap already completed.
  if command -v docker >/dev/null 2>&1; then
    info "Prerequisite ok: docker"
  else
    warn "Missing prerequisite: docker"
    miss=$((miss + 1))
  fi

  if docker compose version >/dev/null 2>&1; then
    info "Prerequisite ok: docker compose"
  else
    warn "Missing prerequisite: docker compose"
    miss=$((miss + 1))
  fi

  if [[ -d "${MAILCOW_DIR}" ]]; then
    info "Prerequisite ok: ${MAILCOW_DIR}"
  else
    warn "Missing Mailcow installation directory: ${MAILCOW_DIR}"
    miss=$((miss + 1))
  fi

  if [[ $miss -gt 0 ]]; then
    err "Prerequisites missing. Run MailcowBootstrap first and ensure Docker Compose plugin is available."
    exit 1
  fi
}

confirm_role() {
  cat <<EOF2
Selected role summary
  ROLE              : ${ROLE}
  HOSTNAME          : ${HOSTNAME}
  MAIL DOMAIN       : ${MAIL_DOMAIN}
  TARGET IP         : ${TARGET_IP}
  MAILCOW_HOSTNAME  : ${MAILCOW_HOSTNAME}
EOF2
}

backup_if_exists() {
  local f="$1"
  if [[ -f "$f" ]]; then
    cp -a "$f" "${f}.bak.${RUN_ID}"
  fi
}

write_postfix_extra_cf() {
  local extra_cf="${MAILCOW_DIR}/data/conf/postfix/extra.cf"
  mkdir -p "$(dirname "${extra_cf}")"
  backup_if_exists "${extra_cf}"

  cat > "${extra_cf}" <<EOF2
# ====================================================================
# MailcowConfig overrides for ${ROLE}
# Hostname: ${HOSTNAME}
# Domain: ${MAIL_DOMAIN}
# ====================================================================
myhostname = ${HOSTNAME}
smtpd_banner = \$myhostname ESMTP Postfix
smtpd_tls_security_level = may
smtpd_tls_auth_only = no
mynetworks = 127.0.0.0/8, 172.22.1.0/24, 192.168.10.0/24
smtpd_client_restrictions = permit_mynetworks, permit_sasl_authenticated
smtpd_sender_restrictions = permit_mynetworks, permit_sasl_authenticated
smtpd_recipient_restrictions = permit_mynetworks, permit_sasl_authenticated, reject_unauth_destination
smtpd_sender_login_maps =
EOF2

  info "Wrote ${extra_cf}"
}

write_rspamd_options() {
  local rspamd_inc="${MAILCOW_DIR}/data/conf/rspamd/custom/options.inc"
  mkdir -p "$(dirname "${rspamd_inc}")"
  backup_if_exists "${rspamd_inc}"

  cat > "${rspamd_inc}" <<EOF2
# Declare structural network spaces as high-trust environments
local_networks = ["127.0.0.1", "172.22.1.0/24", "192.168.10.0/24"];
EOF2

  info "Wrote ${rspamd_inc}"
}

update_mailcow_conf() {
  local cfg="${MAILCOW_DIR}/mailcow.conf"
  if [[ ! -f "${cfg}" ]]; then
    err "Missing ${cfg}. Run MailcowBootstrap first."
    exit 1
  fi
  backup_if_exists "${cfg}"

  if grep -q '^MAILCOW_HOSTNAME=' "${cfg}"; then
    sed -i -E "s|^MAILCOW_HOSTNAME=.*|MAILCOW_HOSTNAME=${MAILCOW_HOSTNAME}|" "${cfg}"
  else
    printf '\nMAILCOW_HOSTNAME=%s\n' "${MAILCOW_HOSTNAME}" >> "${cfg}"
  fi

  if grep -q '^SKIP_CLAMD=' "${cfg}"; then
    sed -i -E 's/^SKIP_CLAMD=.*/SKIP_CLAMD=y/' "${cfg}"
  else
    printf 'SKIP_CLAMD=y\n' >> "${cfg}"
  fi

  if grep -q '^SKIP_OLEFY=' "${cfg}"; then
    sed -i -E 's/^SKIP_OLEFY=.*/SKIP_OLEFY=y/' "${cfg}"
  else
    printf 'SKIP_OLEFY=y\n' >> "${cfg}"
  fi

  if grep -q '^SKIP_LETS_ENCRYPT=' "${cfg}"; then
    sed -i -E 's/^SKIP_LETS_ENCRYPT=.*/SKIP_LETS_ENCRYPT=y/' "${cfg}"
  else
    printf 'SKIP_LETS_ENCRYPT=y\n' >> "${cfg}"
  fi

  if grep -q '^ENABLE_IPV6=' "${cfg}"; then
    sed -i -E 's/^ENABLE_IPV6=.*/ENABLE_IPV6=false/' "${cfg}"
  else
    printf 'ENABLE_IPV6=false\n' >> "${cfg}"
  fi

  info "Updated ${cfg}"
}

apply_hostname() {
  info "Setting hostname to ${HOSTNAME}"
  hostnamectl set-hostname "${HOSTNAME}"
}

restart_mailcow() {
  cd "${MAILCOW_DIR}"
  info "Bringing Mailcow stack up"
  docker compose up -d --remove-orphans
  info "Restarting Postfix and Rspamd to apply configuration"
  docker compose restart postfix-mailcow rspamd-mailcow
}

verify_configuration() {
  cd "${MAILCOW_DIR}"
  local failures=0

  if ! docker compose version >/dev/null 2>&1; then
    err "docker compose not available"
    failures=$((failures + 1))
  else
    info "Verified: docker compose available"
  fi

  if [[ -f "${MAILCOW_DIR}/mailcow.conf" ]] && grep -q "^MAILCOW_HOSTNAME=${MAILCOW_HOSTNAME}$" "${MAILCOW_DIR}/mailcow.conf"; then
    info "Verified: MAILCOW_HOSTNAME=${MAILCOW_HOSTNAME}"
  else
    warn "MAILCOW_HOSTNAME mismatch or missing in mailcow.conf"
    failures=$((failures + 1))
  fi

  if docker compose ps >/dev/null 2>&1; then
    info "Verified: Mailcow compose stack responds"
  else
    warn "Mailcow compose stack did not respond"
    failures=$((failures + 1))
  fi

  if docker ps --format '{{.Names}}' | grep -q 'mailcow'; then
    info "Verified: Mailcow containers present"
  else
    warn "No Mailcow containers detected in docker ps"
    failures=$((failures + 1))
  fi

  return "$failures"
}

write_summary() {
  {
    echo "============================================================"
    echo "MailcowConfig Summary"
    echo "============================================================"
    echo "Role           : ${ROLE}"
    echo "Hostname       : ${HOSTNAME}"
    echo "Domain         : ${MAIL_DOMAIN}"
    echo "Mailcow Host   : ${MAILCOW_HOSTNAME}"
    echo "Target IP      : ${TARGET_IP}"
    echo "Log File       : ${LOG_FILE}"
    echo "============================================================"
  } | tee "${SUMMARY_FILE}" >/dev/null
  cp -f "${SUMMARY_FILE}" "${LATEST_DIR}/status_summary.txt"
  cp -f "${DETAIL_FILE}" "${LATEST_DIR}/detailed_debug.log"
}

configure_mailcow() {
  check_prereqs
  confirm_role
  apply_hostname
  update_mailcow_conf
  write_postfix_extra_cf
  write_rspamd_options
  restart_mailcow
  if verify_configuration; then
    info "Mailcow configuration completed successfully."
  else
    err "Mailcow configuration completed with verification issues."
    exit 1
  fi
}

menu() {
  banner
  cat <<'EOF2'
1) Configure Mailcow
2) Verify configuration
0) Exit
EOF2
}

main() {
  load_config

  while true; do
    menu
    read -r -p "Enter choice [0-2]: " choice
    case "${choice}" in
      1)
        configure_mailcow
        write_summary
        ;;
      2)
        check_prereqs
        verify_configuration || true
        write_summary
        ;;
      0)
        info "Exiting."
        write_summary
        exit 0
        ;;
      *)
        warn "Invalid choice: ${choice}"
        ;;
    esac
  done
}

trap 'err "Unexpected failure at line ${LINENO}"' ERR
main "$@"
