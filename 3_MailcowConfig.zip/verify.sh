#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONF_FILE="${SCRIPT_DIR}/mailcowconfig.conf"
LOG_DIR="${SCRIPT_DIR}/logs"
RUN_TS="$(date +%Y%m%d-%H%M%S)"
LOG_FILE="${LOG_DIR}/verify-${RUN_TS}.log"
LATEST_LOG="${LOG_DIR}/latest-verify.log"
MAILCOW_DIR="/opt/mailcow-dockerized"
MAILCOW_CONF="${MAILCOW_DIR}/mailcow.conf"
POSTFIX_EXTRA="${MAILCOW_DIR}/data/conf/postfix/extra.cf"
RSPAMD_OPTIONS="${MAILCOW_DIR}/data/conf/rspamd/custom/options.inc"

mkdir -p "$LOG_DIR"
: > "$LOG_FILE"
ln -sfn "$LOG_FILE" "$LATEST_LOG" 2>/dev/null || true

PASS=0
FAIL=0
WARN=0

log(){ printf '[%s] %s\n' "$(date '+%F %T')" "$*" | tee -a "$LOG_FILE"; }
pass(){ PASS=$((PASS+1)); log "[PASS] $*"; }
fail(){ FAIL=$((FAIL+1)); log "[FAIL] $*"; }
warn(){ WARN=$((WARN+1)); log "[WARN] $*"; }

# shellcheck disable=SC1090
[[ -f "$CONF_FILE" ]] && source "$CONF_FILE" || true

check_file(){ [[ -f "$1" ]] && pass "$2 present" || fail "$2 missing"; }
check_cmd(){ command -v "$1" >/dev/null 2>&1 && pass "$1 available" || fail "$1 missing"; }

check_file "$MAILCOW_CONF" "mailcow.conf"
check_file "$POSTFIX_EXTRA" "postfix extra.cf"
check_file "$RSPAMD_OPTIONS" "rspamd options.inc"
check_cmd docker
check_cmd git

if [[ -f "$MAILCOW_CONF" && -n "${MAIL_ROLE:-}" ]]; then
  expected="${MAIL_INTERNAL_HOSTNAME:-mail.internal.local}"
  [[ "$MAIL_ROLE" == "external" ]] && expected="${MAIL_EXTERNAL_HOSTNAME:-mail.external.local}"
  if grep -q "^MAILCOW_HOSTNAME=${expected}$" "$MAILCOW_CONF"; then
    pass "MAILCOW_HOSTNAME matches ${expected}"
  else
    fail "MAILCOW_HOSTNAME does not match ${expected}"
  fi
fi

if docker compose -f "${MAILCOW_DIR}/docker-compose.yml" ps >/dev/null 2>&1; then
  pass "Mailcow docker compose reachable"
else
  warn "Mailcow docker compose not yet reachable or stack not running"
fi

log "============================================================"
log "Summary: PASS=${PASS} WARN=${WARN} FAIL=${FAIL}"
log "Log: ${LOG_FILE}"
log "============================================================"
[[ $FAIL -eq 0 ]]
