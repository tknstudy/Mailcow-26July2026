MailcowConfig v1.0.0
====================

Stage 2 for Mailcow.

This package does not install Mailcow itself. It applies role-specific configuration to an already-installed Mailcow instance.

Roles:
- internal -> mail.internal.local / internal.local / 192.168.10.11
- external -> mail.external.local / external.local / 192.168.10.12

Files:
- MailcowConfig.sh
- verify.sh
- mailcowconfig.conf
- templates/extra.cf.template
- templates/options.inc.template
- templates/mailboxes.csv.example

Usage:
1. sudo ./MailcowConfig.sh
2. choose role
3. verify with sudo ./verify.sh
