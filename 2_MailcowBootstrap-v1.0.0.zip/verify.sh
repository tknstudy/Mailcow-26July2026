#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONF_FILE="${SCRIPT_DIR}/mailcowbootstrap.conf"
source "${CONF_FILE}"
MAILCOW_DIR="${MAILCOW_DIR:-/opt/mailcow-dockerized}"

if [[ ${EUID} -ne 0 ]]; then
  echo "Run with sudo/root."
  exit 1
fi

echo "=== MailcowBootstrap verification ==="
[[ -d "${MAILCOW_DIR}" ]] && echo "PASS: Mailcow directory exists" || { echo "FAIL: Mailcow directory missing"; exit 1; }
[[ -f "${MAILCOW_DIR}/mailcow.conf" ]] && echo "PASS: mailcow.conf exists" || echo "WARN: mailcow.conf missing"
if command -v docker >/dev/null 2>&1; then echo "PASS: docker command available"; else echo "FAIL: docker missing"; exit 1; fi
if docker info >/dev/null 2>&1; then echo "PASS: docker daemon responding"; else echo "FAIL: docker daemon not responding"; exit 1; fi
cd "${MAILCOW_DIR}"
docker compose ps || true
