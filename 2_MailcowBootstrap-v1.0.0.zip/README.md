# MailcowBootstrap

Two-stage bootstrap for Mailcow on Rocky Linux lab VMs.

Stage 1 installs and starts Mailcow.
Stage 2 applies the role-specific configuration for internal/external.

## Roles

- internal  -> `mail.internal.local` / `192.168.10.11`
- external  -> `mail.external.local` / `192.168.10.12`

## Usage

```bash
chmod +x MailcowBootstrap.sh verify.sh
sudo ./MailcowBootstrap.sh
sudo ./verify.sh
```

## Files

- `mailcowbootstrap.conf` - default role, host and lab settings
- `templates/extra.cf.template` - Postfix overrides template
- `templates/options.inc.template` - Rspamd trusted-network template
- `templates/mailboxes.csv.example` - mailbox seed example
