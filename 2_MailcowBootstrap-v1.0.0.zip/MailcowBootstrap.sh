#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONF_FILE="${SCRIPT_DIR}/mailcowbootstrap.conf"
MAILCOW_DIR_DEFAULT="/opt/mailcow-dockerized"
MAILCOW_DIR="${MAILCOW_DIR_DEFAULT}"

TS="$(date +%Y%m%d-%H%M%S)"
LOG_ROOT="/var/log/mailcowbootstrap"
RUN_DIR="${LOG_ROOT}/run-${TS}"
LATEST_DIR="${LOG_ROOT}/latest"
SUMMARY_FILE="${RUN_DIR}/summary.txt"
DETAIL_FILE="${RUN_DIR}/detail.log"

mkdir -p "${RUN_DIR}" "${LATEST_DIR}"
ln -sfn "${RUN_DIR}" "${LATEST_DIR}/current" 2>/dev/null || true

if [[ -t 1 ]]; then
  C_RED=$'\033[31m'
  C_GREEN=$'\033[32m'
  C_YELLOW=$'\033[33m'
  C_BLUE=$'\033[34m'
  C_CYAN=$'\033[36m'
  C_RESET=$'\033[0m'
else
  C_RED=""; C_GREEN=""; C_YELLOW=""; C_BLUE=""; C_CYAN=""; C_RESET=""
fi

STAGE_NO=0
TOTAL_STAGES=0
PASS_COUNT=0
FAIL_COUNT=0
WARN_COUNT=0
CURRENT_ROLE=""
MAILCOW_HOSTNAME=""
MAIL_DOMAIN=""
MAIL_SERVER_IP=""
MAIL_GATEWAY=""
MAIL_DNS=""
TRUSTED_NETWORKS=""
ADMIN_USER="admin"
ADMIN_PASS="VMware1!"
MAILCOW_SOURCE_URL="https://github.com/mailcow/mailcow-dockerized.git"
USE_LOCAL_REPO="YES"
REPO_BASEURL=""
ROLE="internal"

stage() {
  STAGE_NO=$((STAGE_NO + 1))
  echo
  echo "${C_BLUE}============================================================${C_RESET}"
  printf '%bSTAGE %d/%d%b %s\n' "${C_CYAN}" "${STAGE_NO}" "${TOTAL_STAGES:-5}" "${C_RESET}" "$1"
  echo "${C_BLUE}============================================================${C_RESET}"
  echo "[$(date '+%F %T')] STAGE ${STAGE_NO}: $1" >> "${DETAIL_FILE}"
}

pass() {
  PASS_COUNT=$((PASS_COUNT + 1))
  printf '%b[PASS]%b %s\n' "${C_GREEN}" "${C_RESET}" "$1"
  echo "PASS: $1" >> "${DETAIL_FILE}"
}

warn() {
  WARN_COUNT=$((WARN_COUNT + 1))
  printf '%b[WARN]%b %s\n' "${C_YELLOW}" "${C_RESET}" "$1"
  echo "WARN: $1" >> "${DETAIL_FILE}"
}

fail() {
  FAIL_COUNT=$((FAIL_COUNT + 1))
  printf '%b[FAIL]%b %s\n' "${C_RED}" "${C_RESET}" "$1"
  echo "FAIL: $1" >> "${DETAIL_FILE}"
}

need_root() {
  if [[ ${EUID} -ne 0 ]]; then
    echo "Run with sudo/root." | tee -a "${DETAIL_FILE}" ; exit 1
  fi
}

load_conf() {
  if [[ ! -f "${CONF_FILE}" ]]; then
    echo "Missing ${CONF_FILE}" | tee -a "${DETAIL_FILE}"; exit 1
  fi
  # shellcheck disable=SC1090
  source "${CONF_FILE}"
  MAILCOW_DIR="${MAILCOW_DIR:-${MAILCOW_DIR_DEFAULT}}"
  ADMIN_USER="${ADMIN_USER:-admin}"
  ADMIN_PASS="${ADMIN_PASS:-VMware1!}"
  MAILCOW_SOURCE_URL="${MAILCOW_SOURCE_URL:-https://github.com/mailcow/mailcow-dockerized.git}"
  USE_LOCAL_REPO="${USE_LOCAL_REPO:-YES}"
  REPO_BASEURL="${REPO_BASEURL:-}"
}

write_summary() {
  {
    echo "MailcowBootstrap Summary"
    echo "Timestamp : $(date)"
    echo "Role      : ${ROLE}"
    echo "Hostname  : ${MAILCOW_HOSTNAME}"
    echo "Domain    : ${MAIL_DOMAIN}"
    echo "Pass      : ${PASS_COUNT}"
    echo "Warn      : ${WARN_COUNT}"
    echo "Fail      : ${FAIL_COUNT}"
    echo "Result    : $([[ ${FAIL_COUNT} -eq 0 ]] && echo PASS || echo FAIL)"
  } > "${SUMMARY_FILE}"
  cp -f "${SUMMARY_FILE}" "${LATEST_DIR}/summary.txt" 2>/dev/null || true
  cp -f "${DETAIL_FILE}" "${LATEST_DIR}/detail.txt" 2>/dev/null || true
}

banner() {
  cat <<'BANNER'
\033[32m############################################################\033[0m
\033[36m#                                                          #\033[0m
\033[36m#   __  __       _ _      ____                 _          #\033[0m
\033[36m#  |  \/  | __ _(_) | ___| __ )  ___  ___ ___ | |__       #\033[0m
\033[36m#  | |\/| |/ _` | | |/ _ \  _ \ / _ \/ __/ __|| '_ \      #\033[0m
\033[36m#  | |  | | (_| | | |  __/ |_) |  __/\__ \__ \| | | |     #\033[0m
\033[36m#  |_|  |_|\__,_|_|_|\___|____/ \___||___/___/|_| |_|     #\033[0m
\033[36m#                                                          #\033[0m
\033[32m#              MailcowBootstrap Deployment                 #\033[0m
\033[33m#                      Version 1.0.0                        #\033[0m
\033[32m############################################################\033[0m
BANNER
}

prompt_defaults() {
  local choice
  echo
  echo "Select role to configure:"
  echo "  1) internal  (mail.internal.local / 192.168.10.11)"
  echo "  2) external  (mail.external.local / 192.168.10.12)"
  read -r -p "Enter choice [1-2]: " choice
  case "${choice}" in
    1)
      ROLE="internal"
      MAILCOW_HOSTNAME="mail.internal.local"
      MAIL_DOMAIN="internal.local"
      MAIL_SERVER_IP="192.168.10.11/24"
      ;;
    2)
      ROLE="external"
      MAILCOW_HOSTNAME="mail.external.local"
      MAIL_DOMAIN="external.local"
      MAIL_SERVER_IP="192.168.10.12/24"
      ;;
    *) echo "Invalid choice"; exit 1 ;;
  esac
  MAIL_GATEWAY="${MAIL_GATEWAY:-192.168.10.1}"
  MAIL_DNS="${MAIL_DNS:-192.168.10.8 172.16.1.10}"
  TRUSTED_NETWORKS="${TRUSTED_NETWORKS:-192.168.10.0/24,172.22.1.0/24}"
}

verify_prereqs() {
  stage "Pre-check prerequisites"
  local missing=()
  for cmd in git curl patch dnf docker; do
    command -v "$cmd" >/dev/null 2>&1 || missing+=("$cmd")
  done
  if [[ ${#missing[@]} -gt 0 ]]; then
    fail "Missing prerequisites: ${missing[*]}"
    return 1
  fi
  pass "Prerequisites present"
}

install_prereqs() {
  stage "Install mailcow prerequisites"
  dnf install -y git curl patch net-tools dnf-plugins-core perl perl-Error perl-Getopt-Long perl-PathTools perl-Data-Dumper perl-File-Path perl-File-Temp perl-IO-Socket-SSL perl-Net-SSLeay perl-TermReadKey >>"${DETAIL_FILE}" 2>&1
  if [[ $? -eq 0 ]]; then pass "Host prerequisites installed"; else fail "Host prerequisites install failed"; fi
}

install_docker() {
  stage "Install Docker Engine"
  dnf install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin >>"${DETAIL_FILE}" 2>&1 || true
  systemctl enable --now docker >>"${DETAIL_FILE}" 2>&1 || true
  if systemctl is-active --quiet docker; then
    pass "Docker running"
  else
    fail "Docker service not active"
  fi
}

fetch_mailcow() {
  stage "Fetch Mailcow sources"
  mkdir -p /opt
  if [[ -d "${MAILCOW_DIR}"/.git ]]; then
    git -C "${MAILCOW_DIR}" pull --rebase >>"${DETAIL_FILE}" 2>&1 || true
  else
    git clone "${MAILCOW_SOURCE_URL}" "${MAILCOW_DIR}" >>"${DETAIL_FILE}" 2>&1
  fi
  if [[ -d "${MAILCOW_DIR}" ]]; then pass "Mailcow sources available"; else fail "Mailcow source checkout failed"; fi
}

generate_mailcow_config() {
  stage "Generate mailcow.conf"
  cd "${MAILCOW_DIR}"
  if [[ ! -f mailcow.conf ]]; then
    printf '%s\n1\n' "${MAILCOW_HOSTNAME}" | ./generate_config.sh >>"${DETAIL_FILE}" 2>&1 || true
  fi
  if [[ -f mailcow.conf ]]; then
    sed -i "s/^MAILCOW_HOSTNAME=.*/MAILCOW_HOSTNAME=${MAILCOW_HOSTNAME}/" mailcow.conf 2>/dev/null || true
    pass "mailcow.conf present"
  else
    fail "mailcow.conf missing"
  fi
}

start_mailcow_stack() {
  stage "Start Mailcow containers"
  cd "${MAILCOW_DIR}"
  docker compose pull >>"${DETAIL_FILE}" 2>&1 || true
  docker compose up -d >>"${DETAIL_FILE}" 2>&1 || true
  sleep 2
  if docker compose ps >>"${DETAIL_FILE}" 2>&1; then
    pass "docker compose stack started"
  else
    warn "docker compose ps could not confirm stack"
  fi
}

apply_role_configuration() {
  stage "Apply internal/external role configuration"
  cd "${MAILCOW_DIR}"
  mkdir -p data/conf/postfix data/conf/rspamd/custom
  local extra_tpl="${SCRIPT_DIR}/templates/extra.cf.template"
  local rspamd_tpl="${SCRIPT_DIR}/templates/options.inc.template"
  if [[ -f "${extra_tpl}" ]]; then
    sed \
      -e "s|{{MAILCOW_HOSTNAME}}|${MAILCOW_HOSTNAME}|g" \
      -e "s|{{TRUSTED_NETWORKS}}|${TRUSTED_NETWORKS}|g" \
      "${extra_tpl}" > data/conf/postfix/extra.cf
    pass "Postfix extra.cf written"
  else
    fail "Missing extra.cf template"
  fi
  if [[ -f "${rspamd_tpl}" ]]; then
    sed \
      -e "s|{{TRUSTED_NETWORKS}}|${TRUSTED_NETWORKS}|g" \
      "${rspamd_tpl}" > data/conf/rspamd/custom/options.inc
    pass "Rspamd options.inc written"
  else
    fail "Missing options.inc template"
  fi
  hostnamectl set-hostname "${MAILCOW_HOSTNAME}" >>"${DETAIL_FILE}" 2>&1 || true
  sed -i "s/^MAILCOW_HOSTNAME=.*/MAILCOW_HOSTNAME=${MAILCOW_HOSTNAME}/" mailcow.conf 2>/dev/null || true
  if docker compose restart postfix-mailcow rspamd-mailcow >>"${DETAIL_FILE}" 2>&1; then
    pass "Role configuration applied"
  else
    warn "Could not restart all role containers"
  fi
}

verify_mailcow() {
  stage "Verification"
  cd "${MAILCOW_DIR}"
  local ok=0
  docker compose ps >>"${DETAIL_FILE}" 2>&1 || true
  if docker compose exec -T postfix-mailcow postconf myhostname smtpd_banner mynetworks smtpd_sender_login_maps >>"${DETAIL_FILE}" 2>&1; then
    ok=1
  fi
  if [[ $ok -eq 1 ]]; then
    pass "Mailcow verification commands succeeded"
  else
    warn "Mailcow verification commands returned warnings"
  fi
}

show_menu() {
  banner
  echo
  echo "Select action:"
  echo "  1) Install Mailcow"
  echo "  2) Configure Mailcow (internal/external)"
  echo "  3) Install + Configure"
  echo "  4) Verify"
  echo "  5) Exit"
}

run_install() { install_prereqs; install_docker; fetch_mailcow; generate_mailcow_config; start_mailcow_stack; }
run_configure() { prompt_defaults; apply_role_configuration; verify_mailcow; }
run_verify() { verify_mailcow; }

main() {
  need_root
  load_conf
  show_menu
  read -r -p "Enter choice [1-5]: " choice
  case "${choice}" in
    1) TOTAL_STAGES=5; run_install ;;
    2) TOTAL_STAGES=3; prompt_defaults; apply_role_configuration; verify_mailcow ;;
    3) TOTAL_STAGES=8; run_install; prompt_defaults; apply_role_configuration; verify_mailcow ;;
    4) TOTAL_STAGES=1; run_verify ;;
    5) echo "Exit" ; exit 0 ;;
    *) echo "Invalid choice" ; exit 1 ;;
  esac
  write_summary
  echo
  echo "Done. Summary: ${SUMMARY_FILE}"
  echo "Detail:   ${DETAIL_FILE}"
}

trap 'echo "Error at line ${LINENO}" >>"${DETAIL_FILE}"; write_summary' ERR
main "$@"
